package jPetStoreSigninUsing_pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JPetStoreRegister_MainClass {

	public static void main(String[] args) throws Exception{
		// Launching browser
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Mandar\\Desktop\\Sonali\\Automation Testing\\Browser Extension\\chromedriver-win32\\chromedriver");
		WebDriver driver=new ChromeDriver();
		//Creating an Object 
		PageObjectModel_JPetStoreRegister jp=new PageObjectModel_JPetStoreRegister();
		jp.maximizeBroswer(driver);
		Thread.sleep(2000);
		jp.url(driver);
		Thread.sleep(2000);
		jp.clickOnSignUp(driver);
		Thread.sleep(2000);
		jp.clickOnRegister(driver);
		Thread.sleep(2000);
		jp.enterUserID(driver, "Simmi");
		Thread.sleep(2000);
		jp.enterNewPassword(driver, "Simmi@123");
		Thread.sleep(2000);
		jp.enterConfirmpassword(driver, "Simmi@123");
		Thread.sleep(2000);
		jp.enterFirstName(driver, "Simmi");
		Thread.sleep(2000);
		jp.enterLastName(driver, "Dev");
		Thread.sleep(2000);
		jp.enterEmail(driver,"simmidev@gmail.com");
		Thread.sleep(2000);
		jp.enterPhoneNumber(driver, "9966774455");
		Thread.sleep(2000);
		jp.enterAddress1(driver,"Karmveernagar");
		Thread.sleep(2000);
		jp.enterAddress2(driver,"Sambhajinagar");
		Thread.sleep(2000);
		jp.enterCity(driver,"Satara");
		Thread.sleep(2000);
		jp.enterState(driver,"Maharashtra");
		Thread.sleep(2000);
		jp.enterZip(driver,"415004");
		Thread.sleep(2000);
		jp.enterCountry(driver,"India");
		Thread.sleep(2000);
		jp.selectLanguagePreference(driver);
		Thread.sleep(2000);
		jp.selectFavouriteCategory(driver);
		Thread.sleep(2000);
		jp.clickCheckBox1(driver);
		Thread.sleep(2000);
		jp.clickCheckBox2(driver);
		Thread.sleep(5000);
		jp.screenshots(driver);
		Thread.sleep(2000);
		jp.clickSaveAccountInformationButton(driver);
		Thread.sleep(2000);
		jp.screenshot(driver);
		Thread.sleep(2000);
		jp.closeBrowser(driver);
		
		
		
		
		
		

	}

}
