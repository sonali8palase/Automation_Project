package frameWorks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class KeyWordDrivenTesting_MainClass {
	public static void main(String[]args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Mandar\\Desktop\\Sonali\\Automation Testing\\Browser Extension\\chromedriver-win32\\chromedriver");
		WebDriver driver=new ChromeDriver();
		//Cresting object for ReadExcelClass 
		KeyWordDrivenTesting_ReadExcelClass kd=new KeyWordDrivenTesting_ReadExcelClass();
		kd.readExcel(driver);
		
	}

}
